# sd project 2021/22

# server properties file
the servers stores information on the folder Storage\primaryserver or Storage\secondaryserver inside the current path, make sure you are in the right path!

# run
- ucDrive {ip} {port} [debug]
- ucDrive {ip} {port} [debug]
- terminal [debug]

note: ip and port must match either primary or secondary server in server.properties

Ana Beatriz Marques, 2018274233

Bárbara Gonçalves, 2018295452

      
